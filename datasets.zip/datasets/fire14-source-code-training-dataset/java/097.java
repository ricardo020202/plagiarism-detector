



public class RunWatchDog{
       public static void main(String []args){
              WatchDog wd = new WatchDog();
              System.out.println("WatchDog is Starting!");
              wd.FirstRead();
              wd.print();
       }
}