public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Welcome to Java"); //ini buat ngeprint
        System.out.println("Welcome to Java"); //ini buat ngeprint lagi
        System.out.println("Welcome to Java"); //ini buat ngeprint lagi lagi
        System.out.println("Welcome to Java"); //ini buat ngeprint lagi lagi lagi
        System.out.println("Welcome to Java"); //ini buat ngeprint lagi lagi lagi lagi
    }
}
