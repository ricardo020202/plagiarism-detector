class HelloWorld
{
	public static void main(String[] args)
	{
		
		// code to print "Welcome to Java"
		System.out.println("Welcome to Java");
		
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Java");
		
		System.out.println("Welcome to Java");
		
		System.out.println("Welcome to Java");
		
		//End of code
		// 25779F8829AB7A7650E85A4CC871E6AC Ganteng
		
	}
	
}