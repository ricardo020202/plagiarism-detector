
public class L5 {

    public static void print() {

        for (int i = 0; i < 5; i++) {
            System.out.print("Welcome to Java\n");
        }
    }

    public static void main(String[] args) {
        print();
    }
}
