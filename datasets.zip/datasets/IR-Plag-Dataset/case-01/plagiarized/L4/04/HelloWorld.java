class HelloWorld
{
	static String s;
	static void Cetak()
	{
		System.out.println(s);
		
		System.out.println(s);
		System.out.println(s);
		
		System.out.println(s);
		
		System.out.println(s);
	}
	public static void main(String[] args)
	{
		s = "Welcome to Java";
		// code to print "Welcome to Java"
		Cetak();
		
		//End of code
		// 25779F8829AB7A7650E85A4CC871E6AC Ganteng
		
	}
	
}