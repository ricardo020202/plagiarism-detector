
public class L4 {

    public static void print() {
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Java");
    }

    public static void main(String[] args) {
        
        print();
    }
}
