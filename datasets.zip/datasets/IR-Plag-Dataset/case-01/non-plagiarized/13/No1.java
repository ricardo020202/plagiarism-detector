

/**
 *
 * @author 9BC88124A9BB1C629D5FFBCD81612170
 */
public class No1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Welcome To Java");
        System.out.println("Welcome To Java");
        System.out.println("Welcome To Java");
        System.out.println("Welcome To Java");
        System.out.println("Welcome To Java");
    }
    
}
