

/**
 *
 * @author B00A50C448238A71ED479F81FA4D9066
 */

public class T01 {
    public static void main(String[] args) {
        for(int i = 0; i < 5; i++) {
            System.out.println("Welcome To Java");
        }
    }
}
