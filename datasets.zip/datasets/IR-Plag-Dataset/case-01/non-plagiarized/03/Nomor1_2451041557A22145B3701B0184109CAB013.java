

/**
 *
 * @author CB6AB3315634A1E4D11B091BA48B60BA
 */
public class Nomor1_2451041557A22145B3701B0184109CAB013 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for(int i=0;i<5;i++)
        {
            System .out.println("Welcome To Java");
        }
    }
    
}
